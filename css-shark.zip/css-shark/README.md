# CSS Shark

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/PoNoBRj](https://codepen.io/alvaromontoro/pen/PoNoBRj).

Cartoon of a shark coded in HTML + CSS