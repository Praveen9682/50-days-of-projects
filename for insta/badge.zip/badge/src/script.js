console.clear()

// const node = document.getElementById('id')
// const node = document.getElementsByClassName('class')
// const nodes = document.querySelectorAll('div')
// window.addEventListener()